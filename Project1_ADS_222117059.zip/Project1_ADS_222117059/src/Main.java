import java.awt.Color;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Graphics;

public class Main
{
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        //System.out.println("Hello World!");
        Main app = new Main();
        app.Start();
    }

    //CONSTANT VARIABLES
    private static final char A = 'A';
    private static final int MAINFRAME_WIDTH = 710;
    private static final int MAINFRAME_HEIGHT = 560;
    private static final int GRAPHPANEL_WIDTH = 550;
    private static final int GRAPHPANEL_HEIGHT = 500;
    private static final int BUTTON_WIDTH = 95;
    private static final int BUTTON_HEIGHT = 30;
    private static final int SPACING = 10;
    private static final int LABEL_LIMIT = 26;
    private static final String MAINFRAME_TITLE = "Dijsktra - Shortest Path";
    private static final String ADDBUTTON_TEXT = "Add";
    private static final String CONNECTBUTTON_TEXT = "Connect";
    private static final String STARTBUTTON_TEXT = "Start";

    //CLASS GLOBAL VARIABLES
    private JFrame mainFrame;
    private JPanel graphPanel;
    private JToggleButton addButton;
    private JToggleButton connectButton;
    private JButton startButton;
    private JComboBox<String> originVertexBox;
    private DefaultComboBoxModel<String> originVertextBoxModel;
    private ActionListener startButtonActionListener;
    private MouseListener addOrConnectMouseListener;
    private int labelCounter;
    private LinkedList<CircleDrawer> circleList;
    private LinkedList<EdgeDrawer> edgeList;
    private Node<CircleDrawer> originNode;
    private Node<CircleDrawer> destinationNode;

    public Main()
    {
        //GUI Component variables
        this.mainFrame = null;
        this.graphPanel = null;
        this.addButton = null;
        this.connectButton = null;
        this.startButton = null;
        this.originVertexBox = null;
        this.originVertextBoxModel = null;

        //Event related variables
        startButtonActionListener = null;
        addOrConnectMouseListener = null;

        //Data structure variables
        labelCounter = 0;
        circleList = new LinkedList<CircleDrawer>();
        originNode = null;
        destinationNode = null;
        edgeList = new LinkedList<EdgeDrawer>();
    }

    public void Start()
    {
        createMainFrame();
        createPanel();
        createButton();
        showOrHideMainFrame(true);

        setupEventListener();
    }

    private void showOrHideMainFrame(boolean isShow)
    {
        this.mainFrame.setVisible(isShow);
    }

    private void createMainFrame()
    {
        //1. Create the frame
        this.mainFrame = new JFrame(MAINFRAME_TITLE);

        //2. Optional: What happens when the frame closes?
        this.mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //3. Set the layout
        this.mainFrame.setLayout(null);

        //4. Size the frame.
        this.mainFrame.setSize(MAINFRAME_WIDTH, MAINFRAME_HEIGHT);
        //4a. The mainframe cannot be resized.
        this.mainFrame.setResizable(false);
    }

    private void createPanel()
    {
        //1. Create the panel to draw the vertices and edges
        //1a. Also, override the paintComponent method
        //to customize the way the panel repaint itself
        //so that it can include drawing the circle
        this.graphPanel = new JPanel()
        {
            @Override
            public void paintComponent(Graphics g)
            {
                super.paintComponent(g);
                if(circleList.Count() > 0)
                {
                    Node<CircleDrawer> temp = circleList.GetHeadNode();
                    while(temp != null)
                    {
                        temp.GetNodeData().DrawCircle(g);
                        temp = temp.GetNextNode();
                    }
                }
                if(edgeList.Count() > 0)
                {
                    Node<EdgeDrawer> temp = edgeList.GetHeadNode();
                    while(temp != null)
                    {
                        temp.GetNodeData().DrawEdge(g);
                        temp = temp.GetNextNode();
                    }
                }
            }
        };

        //2. Set the layout: null = absolute layout
        this.graphPanel.setLayout(null);

        //3. Set the background color
        this.graphPanel.setBackground(Color.WHITE);

        //4. Set the location of the panel in respect to the mainframe
        this.graphPanel.setBounds(SPACING, SPACING, GRAPHPANEL_WIDTH, GRAPHPANEL_HEIGHT);

        //5. Add it to the mainframe
        this.mainFrame.add(this.graphPanel);
    }

    private void createButton()
    {
        //1. Create the panel to contain all of the buttons
        JPanel buttonPanel = new JPanel();
        //1a. Set the layout to null == absolute layout
        buttonPanel.setLayout(null);
        //1b. Show the border of the panel
        buttonPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //1c. Set the location of the panel in respect to the mainframe
        buttonPanel.setBounds(570, 10, 115, 170);
        buttonPanel.setBounds(this.graphPanel.getX()+this.graphPanel.getWidth()+SPACING,
                SPACING,
                BUTTON_WIDTH+(SPACING*2),
                (BUTTON_HEIGHT*4)+(SPACING*5));

        //ADD BUTTON
        //2. Create add button
        this.addButton = new JToggleButton(ADDBUTTON_TEXT);
        //2a. Set the location and the size of the button in respect to the button panel
        this.addButton.setBounds(SPACING,SPACING,BUTTON_WIDTH,BUTTON_HEIGHT);
        //2b. Add it to the button panel
        buttonPanel.add(this.addButton);

        //CONNECT BUTTON
        //3. Create add button
        this.connectButton = new JToggleButton(CONNECTBUTTON_TEXT);
        //3a. Set the location and the size of the button in respect to the button panel
        this.connectButton.setBounds(SPACING,(SPACING*2)+BUTTON_HEIGHT,BUTTON_WIDTH,BUTTON_HEIGHT);
        //3b. Add it to the button panel
        buttonPanel.add(this.connectButton);

        //ORIGIN VERTEX COMBOBOX
        //4. Create the combobox model
        this.originVertextBoxModel = new DefaultComboBoxModel<String>();
        //4a. Create the combobox component
        this.originVertexBox = new JComboBox<String>(this.originVertextBoxModel);
        //4b. Set the combobox editor background color
        this.originVertexBox.setBackground(Color.WHITE);
        //4c. Set the alignement of the combobox item text to be centered
        ((JLabel)this.originVertexBox.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        //4d. Set the location and the size of the button in respect to the button panel
        this.originVertexBox.setBounds(SPACING,(SPACING*3)+(BUTTON_HEIGHT*2),BUTTON_WIDTH,BUTTON_HEIGHT);
        //4e. Add it to the button panel
        buttonPanel.add(this.originVertexBox);

        //START BUTTON
        //5. Create add button
        this.startButton = new JButton(STARTBUTTON_TEXT);
        //5a. Set the location and the size of the button in respect to the button panel
        this.startButton.setBounds(SPACING,(SPACING*4)+(BUTTON_HEIGHT*3),BUTTON_WIDTH,BUTTON_HEIGHT);
        //5b. Add it to the button panel
        buttonPanel.add(this.startButton);

        //6. Group the toggle buttons, so only one toggle button can be selected at a time
        groupToggleButton();

        //7. Add the button panel to mainframe
        this.mainFrame.add(buttonPanel);
    }

    private void groupToggleButton()
    {
        //Group the toggle button, so only one toggle button can be selected at a time
        ButtonGroup groupToggleButton = new ButtonGroup();
        groupToggleButton.add(addButton);
        groupToggleButton.add(connectButton);
    }

    private void setupEventListener()
    {
        createEventListener();
        registerEventListener();
    }






    private Node<CircleDrawer> searchNode(String name){
        Node<CircleDrawer> temp = circleList.GetHeadNode();

        if(circleList.Count() > 0)
        {
            while(temp != null && temp.GetNodeName() != name)
            {
                temp = temp.GetNextNode();
            }
        }
        if(temp.GetNodeName() == name) {
            return temp;
        }else {
            return null;
        }
    }

    private Node<EdgeDrawer> searchEdge(String origin, String dest){
        Node<EdgeDrawer> temp = edgeList.GetHeadNode();
        String str1 = temp.GetNodeName();
        String str2 = origin+dest;
        if(edgeList.Count()>0) {
            while(temp != null && !str1.equals(str2))
            {

                temp = temp.GetNextNode();
                if(temp != null) {
                    str1 = temp.GetNodeName();
                }


            }
        }
        return temp;
    }

    public class ShortestPath {
        public String nodeName;
        public int distance;
        public boolean flag;
    }

    public int[] findMin(ShortestPath dist[]) {
        int len = dist.length;
        int min = Integer.MAX_VALUE;
        int minIdx = 0;
        for(int i=1; i<len; ++i) {
            if(!dist[i].flag && (dist[i].distance < min)) {
                min = dist[i].distance;
                minIdx = i;
            }
        }
        dist[minIdx].flag = true;
        int[] ans = new int[2];
        ans[0] = minIdx;
        ans[1] = min;
        return ans;
    }
    private void createEventListener(){
        this.startButtonActionListener=new ActionListener(){
            public void actionPerformed(ActionEvent actionEvent){
                //TODO: call Dijkstra's Algorithm here
                System.out.println("Start button is clicked");
                if(circleList.Count() > 0) {
                    int len =  circleList.Count();
                    ShortestPath dist[] = new ShortestPath[len];
                    ShortestPath end = null;
                    Node<CircleDrawer> tempCircle = circleList.GetHeadNode();
                    if(tempCircle != null) {
                        for(int i=0; i<len; ++i) {
                            dist[i] = new ShortestPath();
                            dist[i].nodeName = tempCircle.GetNodeName();
                            if(originVertexBox.getSelectedItem() == dist[i].nodeName) {
                                end = dist[i];
                            }
                            dist[i].distance = Integer.MAX_VALUE;
                            dist[i].flag = false;
                            tempCircle = tempCircle.GetNextNode();
                        }
                    }
                    dist[0].distance = 0;
                    dist[0].flag = true;
                    if(dist[0] == end) {
                        System.out.println("The shortest distance is 0");
                    }else {
                        ShortestPath mark = dist[0];
                        Node<EdgeDrawer> currEdge = null;
                        int total = 0;
                        int count = 0;
                        while(!end.flag && count<(len-1)) {
                            for(int j=1; j<len; ++j) {
                                if(!dist[j].flag) {
                                    currEdge = searchEdge(mark.nodeName,dist[j].nodeName);
                                    if(currEdge!=null) {
                                        if( (total + currEdge.GetNodeData().GetDistance()) < dist[j].distance) {
                                            dist[j].distance = total + currEdge.GetNodeData().GetDistance();
                                        }
                                    }
                                }
                            }total = findMin(dist)[1];
                            mark = dist[findMin(dist)[0]];
                            ++count;
                        }
                        if(end.flag == false) {
                            System.out.println("Path not found!");
                        }else {
                            System.out.println("The shortest distance is "+ end.distance);
                        }
                    }
                }
            }
        };
        this.addOrConnectMouseListener = new MouseListener() {

            @Override
            public void mouseReleased(MouseEvent e) {
                // TODO Auto-generated method stub
                System.out.println("Mouse is released at, X = " + e.getX() + ", Y = " + e.getY()); //test code

                //Draw the edge if the connect button is selected
                //and if mouse are pressed and released on a circle
                if(connectButton.isSelected() && originNode != null)
                {
                    destinationNode = findNode(e.getX(), e.getY());
                    if(destinationNode != null && destinationNode.GetNodeName() != originNode.GetNodeName())
                    {
                        EdgeDrawer newEdge = new EdgeDrawer(originNode.GetNodeData(),
                                destinationNode.GetNodeData(),
                                originNode.GetNodeName()+destinationNode.GetNodeName());
                        if(!isEdgeExist(newEdge))
                        {
                            Node<EdgeDrawer> newEdgeNode =
                                    new Node<EdgeDrawer>(newEdge, newEdge.GetLabel());
                            edgeList.Add(newEdgeNode);
                            edgeList.Print(); //test code
                        }
                    }
                }
                //Refresh / repaint the graph panel
                graphPanel.repaint();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                // TODO Auto-generated method stub
                System.out.println("Mouse is pressed at, X = " + e.getX() + ", Y = " + e.getY()); //test code

                //Draw the edge if the connect button is selected
                //and if mouse are pressed and released on a circle
                if(connectButton.isSelected())
                {
                    originNode = findNode(e.getX(), e.getY());
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // TODO Auto-generated method stub

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                // TODO Auto-generated method stub

            }

            @Override
            public void mouseClicked(MouseEvent e) {
                // TODO Auto-generated method stub
                System.out.println("Mouse is clicked at, X = " + e.getX() + ", Y = " + e.getY()); //test code

                //Draw the circle if add toggle button is selected
                if(addButton.isSelected())
                {
                    if(labelCounter < LABEL_LIMIT)
                    {
                        CircleDrawer newCircle = new CircleDrawer(e.getX(), e.getY(), getLabel());
                        labelCounter++;
                        Node<CircleDrawer> newCircleNode =
                                new Node<CircleDrawer>(newCircle, newCircle.GetLabel());
                        circleList.Add(newCircleNode);
                        circleList.Print(); //test code

                        //Also, update the combobox items
                        originVertextBoxModel.addElement(newCircle.GetLabel());
                    }
                }
                //Refresh / repaint the graph panel
                graphPanel.repaint();
            }
        };
    }

    private void registerEventListener()
    {
        this.startButton.addActionListener(startButtonActionListener);
        this.graphPanel.addMouseListener(addOrConnectMouseListener);
    }

    private String getLabel()
    {
        char temp = (char)(A+labelCounter);
        return String.valueOf(temp);

    }

    private Node<CircleDrawer> findNode(int xParam, int yParam)
    {
        Node<CircleDrawer> temp = this.circleList.GetHeadNode();

        if(this.circleList.Count() > 0)
        {
            while(temp != null
                    && !temp.GetNodeData().IsInCircle(xParam, yParam))
            {
                temp = temp.GetNextNode();
            }
        }

        return temp;
    }

    private boolean isEdgeExist(EdgeDrawer edgeParam)
    {
        boolean isExist = false;
        Node<EdgeDrawer> temp = this.edgeList.GetHeadNode();

        if(this.edgeList.Count() > 0)
        {
            while(temp != null && !isExist)
            {
                isExist = temp.GetNodeData().IsEdgeExist(edgeParam);
                temp = temp.GetNextNode();
            }
        }

        return isExist;
    }
}
