import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;

public class EdgeDrawer
{
	private Node source;
	private Node destination;
	private int weight;
	// Other properties and methods specific to your application

	//STATIC VARIABLES
	private static final int FONT_SIZE = 11;
	private static final String FONT_NAME = "TimesRoman";

	//GLOBAL VARIABLES
	private String label;
	private int distance;
	private CircleDrawer originCircle;
	private CircleDrawer destinationCircle;

	public EdgeDrawer(CircleDrawer oriParam, CircleDrawer destParam, String lblParam)
	{
		this.label = lblParam;
		this.originCircle = oriParam;
		this.destinationCircle = destParam;
		calculateDistance();
	}

	public String GetLabel()
	{
		return this.label;
	}

	public int GetDistance()
	{
		return this.distance;
	}

	private Point getCenterPointEdge()
	{
		int centerX = this.originCircle.GetCenterPoint().x + Math.abs(this.originCircle.GetCenterPoint().x - this.destinationCircle.GetCenterPoint().x)/2;
		int centerY = this.originCircle.GetCenterPoint().y + Math.abs(this.originCircle.GetCenterPoint().y - this.destinationCircle.GetCenterPoint().y)/2;
		return new Point(centerX, centerY);
	}

	private void calculateDistance()
	{
		int a = Math.abs(this.originCircle.GetCenterPoint().x - this.destinationCircle.GetCenterPoint().x);
		int b = Math.abs(this.originCircle.GetCenterPoint().y - this.destinationCircle.GetCenterPoint().y);

		this.distance = (int)Math.sqrt((a*a)+(b*b));
	}

	public boolean IsEdgeExist(EdgeDrawer edgeParam)
	{
		boolean isExist = false;

		if(this.label.contains(edgeParam.originCircle.GetLabel())
				&& this.label.contains(edgeParam.destinationCircle.GetLabel()))
		{
			isExist = true;
		}

		return isExist;
	}

	public void DrawEdge(Graphics edge)
	{
		//1. Set the circle
		edge.setColor(Color.BLUE);
		edge.drawLine(this.originCircle.GetCenterPoint().x, this.originCircle.GetCenterPoint().y,
				this.destinationCircle.GetCenterPoint().x, this.destinationCircle.GetCenterPoint().y);

		//2. Set and draw the label of the edge
		drawLabel(edge);
	}

	private void drawLabel(Graphics edge)
	{
		//1. Set the label of the edge
		edge.setFont(new Font(FONT_NAME, Font.PLAIN, FONT_SIZE));
		edge.setColor(Color.BLACK);
		edge.drawString(this.label+" = "+String.valueOf(this.distance),
				getCenterPointEdge().x,
				getCenterPointEdge().y);
	}
}