public class LinkedList<T>
{
	private Node<T> head;

	public LinkedList()
	{
		this.head = null;
	}

	public void Add(Node<T> newNode)
	{
		if(this.head == null)
		{
			this.head = newNode;
		}
		else
		{
			Node<T> temp = this.head;
			while(temp.GetNextNode() != null)
			{
				temp = temp.GetNextNode();
			}
			temp.SetNextNode(newNode);
		}
	}

	public void Remove()
	{
		if(this.head != null)
		{
			if(this.head.GetNextNode() == null)
			{
				this.head = null;
			}
			else
			{
				Node<T> prev = this.head;
				Node<T> curr = this.head;
				while(curr.GetNextNode() != null)
				{
					prev = curr;
					curr = curr.GetNextNode();
				}
				prev.SetNextNode(null);
			}
		}
	}

	public int Count()
	{
		int counter = 0;
		Node<T> temp = this.head;

		while(temp != null)
		{
			counter++;
			temp = temp.GetNextNode();
		}

		return counter;
	}

	public void Print()
	{
		Node<T> temp = this.head;
		while(temp != null)
		{
			System.out.println(temp.GetNodeName());
			temp = temp.GetNextNode();
		}
	}

	public Node<T> GetHeadNode()
	{
		return this.head;
	}
}
