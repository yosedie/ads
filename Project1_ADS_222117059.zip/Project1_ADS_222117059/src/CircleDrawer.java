import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;

public class CircleDrawer
{
	//STATIC VARIABLES
	private static final int RADIUS = 20;
	private static final int FONT_SIZE = 11;
	private static final int LABEL_OFFSET = 3;
	private static final String FONT_NAME = "TimesRoman";

	//GLOBAL VARIABLES
	private int centerX;
	private int centerY;
	private String label;

	public CircleDrawer(int mouseClickedX, int mouseClickedY, String lblParam)
	{
		this.centerX = mouseClickedX;
		this.centerY = mouseClickedY;
		this.label = lblParam;
	}

	public String GetLabel()
	{
		return this.label;
	}

	public Point GetCenterPoint()
	{
		return new Point(this.centerX, this.centerY);
	}

	public boolean IsInCircle(int xParam, int yParam)
	{
		boolean retValue = false;

		if(xParam >= this.centerX-RADIUS && xParam <= this.centerX+RADIUS
				&& yParam >= this.centerY-RADIUS && yParam <= this.centerY+RADIUS)
		{
			retValue = true;
		}

		return retValue;
	}

	public void DrawCircle(Graphics circle)
	{
		//1. Set the circle
		circle.setColor(Color.YELLOW);
		circle.fillOval(this.centerX-RADIUS,this.centerY-RADIUS, 2*RADIUS, 2*RADIUS);

		//2. Set and draw the label of the circle
		drawLabel(circle);
	}

	private void drawLabel(Graphics circle)
	{
		//1. Set the label of the circle
		circle.setFont(new Font(FONT_NAME, Font.PLAIN, FONT_SIZE));
		FontMetrics fontMetric = circle.getFontMetrics();
		circle.setColor(Color.GREEN);
		circle.drawString(this.label,
				this.centerX-(fontMetric.stringWidth(this.label)/LABEL_OFFSET),
				this.centerY+(fontMetric.getHeight()/LABEL_OFFSET));
	}
}