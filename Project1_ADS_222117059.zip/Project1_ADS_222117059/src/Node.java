public class Node<T>
{
	private String id;
	// Other properties and methods specific to your application
	private String nodeName;
	private T data;
	private Node<T> next;

	public Node(T dataParam, String nodeNameParam)
	{
		this.nodeName = nodeNameParam;
		this.data = dataParam;
		this.next = null;
	}

	public void SetNextNode(Node<T> nextNodeParam)
	{
		this.next = nextNodeParam;
	}

	public Node<T> GetNextNode()
	{
		return this.next;
	}

	public T GetNodeData()
	{
		return this.data;
	}

	public String GetNodeName()
	{
		return this.nodeName;
	}
}
